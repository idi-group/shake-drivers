package foo.shaketest;

import java.util.ArrayList;
import java.util.Iterator;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

public class SensorDisplay extends View {

	public SensorDisplay(Context context, AttributeSet attrs) {
		super(context, attrs);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SensorDisplay);
		bgcol = a.getColor(R.styleable.SensorDisplay_bgColor, bgcol);
		inputCount = a.getInt(R.styleable.SensorDisplay_inputCount, inputCount);
		fgCols[0] = a.getInt(R.styleable.SensorDisplay_fgColor1, fgCol1);
		fgCols[1] = a.getInt(R.styleable.SensorDisplay_fgColor2, fgCol2);
		fgCols[2] = a.getInt(R.styleable.SensorDisplay_fgColor3, fgCol3);
		lineWidth = a.getInt(R.styleable.SensorDisplay_lineWidth, lineWidth);
		yMax = a.getInt(R.styleable.SensorDisplay_yMax, yMax);
		yMin = a.getInt(R.styleable.SensorDisplay_yMin, yMin);
		xRange = a.getInt(R.styleable.SensorDisplay_xRange, xRange);
		label = a.getString(R.styleable.SensorDisplay_label);
		
		buffers = new int[inputCount][xRange];
		buffer_indexes = new int[inputCount];
		
		paints = new Paint[inputCount];
		for(int i=0;i<inputCount;i++) {
			buffer_indexes[i] = 0;
			paints[i] = new Paint();
			paints[i].setColor(fgCols[i]);
		}
		
		textpaint = new Paint();
		textpaint.setColor(0xFFFFFFFF);
		
		a.recycle();
	}

	// for manual instantiation...
	public SensorDisplay(Context context) {
		super(context);
	}
	
	private float scale(int rawdatavalue) {
		return _height - (int)((rawdatavalue + yoffset) * yscale);
	}
	
	// one entry in array per data stream
	public void updateData(int[] newdata) {
		started = true;
		for(int i=0;i<inputCount;i++) {
			buffers[i][buffer_indexes[i]] = (int)scale(newdata[i]);
			buffer_indexes[i]++;
			if(buffer_indexes[i] == xRange) buffer_indexes[i] = 0;
		}
		invalidate();
	}
	
	// TODO fix this
	private float[] buildPointList(int buffer) {
		float[] linepoints = new float[xRange*4];
		int linepointsindex = 0;
		int bindex = buffer_indexes[buffer];
		float[] lastpoint = null;
		
		for(int j=0;j<xRange;j++) {
			float xpos = j * xstep;
			float ypos = buffers[buffer][bindex++];
			
			if(j < 2) {
				linepoints[linepointsindex++] = xpos;
				linepoints[linepointsindex++] = ypos;
			} else {
				linepoints[linepointsindex++] = lastpoint[0];
				linepoints[linepointsindex++] = lastpoint[1];
				linepoints[linepointsindex++] = xpos; 
				linepoints[linepointsindex++] = ypos;
			}
			
			lastpoint = new float[]{xpos, ypos};
		
			if(bindex == xRange) bindex = 0;
		}
		
		return linepoints;
	}
	
	public void onDraw(Canvas canvas) {
		canvas.drawColor(bgcol);
		
		if(started) {
			for(int i=0;i<inputCount;i++) {
				float[] lines = buildPointList(i);
				canvas.drawLines(lines, 0, lines.length, paints[i]);
			}
		}
		
		if(label != null) canvas.drawText(label, 5, 20, textpaint);
	}
	
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		_width = MeasureSpec.getSize(widthMeasureSpec);
		_height = MeasureSpec.getSize(heightMeasureSpec);
		setMeasuredDimension(_width, _height);
		
		xstep = _width / (float)xRange;
		
		yscale = getHeight() / (float)(yMax - yMin);
		yoffset = 0;
		if (yMin < 0)
			yoffset = Math.abs(yMin);
	}

	private int bgcol = 0xFF000000;
	private int inputCount = 3;
	private int fgCol1 = 0xFFFF0000;
	private int fgCol2 = 0xFF00FF00;
	private int fgCol3 = 0xFF0000FF;
	private int fgCols[] = new int[3];
	private int lineWidth = 2;
	private int yMax = 2000;
	private int yMin = -2000;
	private int xRange = 30;
	private String label = null;
	
	private int[][] buffers = null;
	private int[] buffer_indexes = null;
	
	private Paint[] paints = null;
	private Paint textpaint = null;
	private float xstep = 0.0f;
	private float yscale = 0.0f;
	private int yoffset = 0;
	private int _width = 0;
	private int _height = 0;
	private boolean started = false;
}
